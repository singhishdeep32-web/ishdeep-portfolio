import { ArrowLeft, Check } from 'lucide-react';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Thank you — Ishdeep Singh', robots: { index: false, follow: true } };
export default function Thanks(){return <main className="thanks-page"><span className="thanks-check"><Check size={25}/></span><p className="eyebrow">THANK YOU FOR REACHING OUT</p><h1>You’re all set<span>.</span></h1><p>Your contact form has been submitted. I look forward to learning more about your idea.</p><a className="primary-link" href="/"><ArrowLeft size={16}/> Back to my portfolio</a></main>}
