import { ArrowUpRight, ArrowDown, Download, MapPin, Check } from 'lucide-react';
import ContactForm from './contact-form';
import CopyEmail from './copy-email';

const github = 'https://github.com/singhishdeep32-web';
const linkedin = 'https://www.linkedin.com/in/ishdeep-singh-19656b2a1/';
const resume = '/Ishdeep-Singh-Resume.pdf';
const skillGroups = [
  ['Development', ['Python', 'C / C++', 'Java', 'PHP', 'HTML & CSS', 'JavaScript']],
  ['AI & quality', ['AI evaluation', 'Data annotation', 'Code review', 'Testing & debugging', 'Prompt analysis']],
  ['Data & workflow', ['SQL', 'MySQL', 'Oracle', 'Git & GitHub', 'Data structures', 'Agile fundamentals']],
];

export default function Home() {
  return <>
    <a href="#main" className="skip-link">Skip to content</a>
    <header className="header"><div className="header-inner"><a href="#" className="brand" aria-label="Ishdeep Singh, home">is<span>.</span></a><nav aria-label="Main navigation"><a href="#about">About</a><a href="#experience">Experience</a><a href="#work">Work</a><a href="#skills">Skills</a><a href="#contact" className="nav-contact">Contact <ArrowUpRight size={14}/></a></nav></div></header>
    <main id="main" className="container">
      <section className="hero" id="about" aria-labelledby="hero-heading">
        <div className="hero-top"><span className="availability"><span className="dot"/> Open to remote opportunities</span><span className="location"><MapPin size={14}/> Patiala, India</span></div>
        <p className="eyebrow">DEVELOPER & AI TRAINER</p>
        <h1 id="hero-heading">Ishdeep Singh<span>.</span></h1>
        <p className="hero-description">Thoughtful code.<br/><span>A careful eye for quality.</span></p>
        <p className="intro">I’m a BCA graduate with experience in AI evaluation, code review, and software testing. I bring curiosity and clear thinking to technical problems.</p>
        <div className="hero-actions"><a href="#contact" className="primary-link">Get in touch <ArrowUpRight size={17}/></a><a href={resume} download className="secondary-link"><Download size={16}/> Download CV</a><a href="#experience" className="text-link">Explore my experience <ArrowDown size={15}/></a></div>
        <dl className="quick-facts"><div><dt>EXPERIENCE</dt><dd>AI Trainer · Handshake AI</dd></div><div><dt>EDUCATION</dt><dd>BCA · May 2026</dd></div><div><dt>FOCUS</dt><dd>Development, AI & QA</dd></div></dl>
      </section>

      <section id="experience" className="content-section section-grid"><div className="section-label"><span>01</span><h2>Experience</h2></div><div className="section-body"><article><div className="row-heading"><div><h3>AI Trainer</h3><p className="subheading">Handshake AI</p></div><span className="badge">Remote</span></div><p className="section-description">Evaluating AI outputs with the same attention I bring to code: understand the intent, test the reasoning, and look closely at the details.</p><ul className="check-list"><li><Check size={15}/>Review responses for accuracy, relevance, completeness, and instruction-following.</li><li><Check size={15}/>Apply structured rubrics to rank and annotate training examples.</li><li><Check size={15}/>Review code, validate tests, and analyze edge cases.</li><li><Check size={15}/>Write clear corrections while meeting quality standards and deadlines.</li></ul></article></div></section>

      <section id="work" className="content-section section-grid"><div className="section-label"><span>02</span><h2>Selected work</h2></div><div className="section-body"><article className="project"><div className="row-heading"><span className="eyebrow">SOFTWARE ENGINEERING</span><span className="badge">Project experience</span></div><h3>Custom expression evaluator</h3><p>Parsing and evaluating expressions with custom operators for a Handshake Dynamo task. The challenge: getting precedence, associativity, and unusual operator behavior right.</p><div className="tags"><span>Parsing</span><span>Edge-case testing</span><span>Docker & CI</span></div><details><summary>How I approached it <span aria-hidden="true">+</span></summary><div className="detail-content"><p>I started with parsing, added the custom operator rules, and then tested tricky expressions. The implementation also needed to fit the repository structure and its Docker and CI setup.</p><p>My focus was to make the rules explicit and check behavior beyond the straightforward examples.</p></div></details></article><article className="project"><div className="row-heading"><span className="eyebrow">PERSONAL EXPLORATION</span><span className="badge in-progress"><span className="dot"/> In development</span></div><h3>AI trading bot</h3><p>Exploring algorithmic trading and AI-assisted analysis, with a focus on learning how to test strategies and handle uncertainty.</p><div className="tags"><span>Algorithmic trading</span><span>AI exploration</span></div></article><a href={github} target="_blank" rel="noreferrer" className="text-link section-link">Find me on GitHub <ArrowUpRight size={15}/></a></div></section>

      <section id="skills" className="content-section section-grid"><div className="section-label"><span>03</span><h2>Skills & tools</h2></div><div className="section-body">{skillGroups.map(([name,tags])=><div className="skill-group" key={name as string}><h3>{name}</h3><div className="tags">{(tags as string[]).map(tag=><span key={tag}>{tag}</span>)}</div></div>)}<p className="skill-extra">Also familiar with React and Angular. Foundations in operating systems, networking, relational databases, and technical documentation.</p></div></section>

      <section id="education" className="content-section section-grid"><div className="section-label"><span>04</span><h2>Background</h2></div><div className="section-body"><div className="education"><div className="row-heading"><h3>Bachelor of Computer Applications</h3><span className="meta">May 2026</span></div><p>Completed coursework in programming, databases, data structures, operating systems, networking, and software development.</p></div><div className="education"><h3>St. Xavier School, Patiala</h3><p>Class 12 · 89% <span className="divider">/</span> High School · 7 CGPA</p></div><div className="about-note"><p>I’m based in Patiala, India, and interested in remote opportunities in development, AI evaluation, and software quality.</p><p><span className="label-inline">Languages</span> English, Hindi & Punjabi · Fluent</p></div></div></section>

      <section id="contact" className="content-section contact-section"><div className="contact-intro"><div className="section-label"><span>05</span><h2>Let’s talk</h2></div><h3>Have something<br/>in mind?</h3><p>A role, a project, or a good question.<br/>I’d love to hear from you.</p><a className="email-link" href="mailto:singhishdeep32@gmail.com">singhishdeep32@gmail.com <ArrowUpRight size={15}/></a><CopyEmail/><div className="social-links"><a href={linkedin} target="_blank" rel="noreferrer">LinkedIn <ArrowUpRight size={14}/></a><a href={github} target="_blank" rel="noreferrer">GitHub <ArrowUpRight size={14}/></a></div></div><ContactForm/></section>
    </main>
    <footer className="footer container"><span>© 2026 Ishdeep Singh</span><a href={resume} download>Download resume <Download size={14}/></a><a href="#">Back to top ↑</a></footer>
  </>;
}
