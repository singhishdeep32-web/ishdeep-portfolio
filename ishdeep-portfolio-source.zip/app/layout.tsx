import type { Metadata } from 'next';
import './globals.css';
const url='https://ishdeep-singh-portfolio.singhishdeep32.chatgpt.site';
export const metadata: Metadata = {
  metadataBase: new URL(url),
  title: 'Ishdeep Singh — Developer & AI Trainer',
  description: 'Explore Ishdeep Singh’s experience, technical skills, projects, and CV. Developer, AI trainer, and BCA graduate in Patiala, India. Get in touch about remote work.',
  alternates: { canonical: '/' },
  openGraph: { title: 'Ishdeep Singh — Developer & AI Trainer', description: 'Thoughtful code. A careful eye for quality. Experience, projects, skills, and contact.', type: 'website', url },
  robots: {index:true,follow:true},
  icons: { icon: '/favicon.svg' },
};
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  const profile={ '@context':'https://schema.org','@type':'Person',name:'Ishdeep Singh',url,jobTitle:'Developer & AI Trainer',email:'mailto:singhishdeep32@gmail.com',sameAs:['https://github.com/singhishdeep32-web','https://www.linkedin.com/in/ishdeep-singh-19656b2a1/'],knowsLanguage:['English','Hindi','Punjabi'] };
  return <html lang="en"><body><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(profile).replace(/</g,'\\u003c')}}/>{children}</body></html>;
}
