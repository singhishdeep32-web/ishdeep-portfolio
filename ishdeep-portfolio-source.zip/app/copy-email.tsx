'use client';
import { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
export default function CopyEmail() {
  const [status,setStatus] = useState('');
  async function copy(){try{await navigator.clipboard.writeText('singhishdeep32@gmail.com');setStatus('Copied');}catch{setStatus('Select the email address above to copy it.');}}
  return <div className="copy-email"><Button type="button" variant="ghost" onClick={copy} aria-label="Copy email address">{status==='Copied'?<Check size={14}/>:<Copy size={14}/>} {status==='Copied'?'Email copied':'Copy email'}</Button><span role="status" className={status==='Copied'?'sr-only':''}>{status}</span></div>;
}
