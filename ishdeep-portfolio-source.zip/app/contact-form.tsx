'use client';
import { useEffect, useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';

export default function ContactForm() {
  const [sending, setSending] = useState(false);
  useEffect(() => {
    const reset = () => setSending(false);
    window.addEventListener('pageshow', reset);
    return () => window.removeEventListener('pageshow', reset);
  }, []);
  return <form className="contact-form" action="https://formsubmit.co/singhishdeep32@gmail.com" method="POST" onSubmit={() => setSending(true)}>
    <input type="hidden" name="_subject" value="New portfolio enquiry — Ishdeep Singh"/>
    <input type="hidden" name="_template" value="table"/>
    <input type="hidden" name="_next" value="https://ishdeep-singh-portfolio.singhishdeep32.chatgpt.site/thanks"/>
    <input type="hidden" name="_url" value="https://ishdeep-singh-portfolio.singhishdeep32.chatgpt.site/"/>
    <div className="honeypot" aria-hidden="true"><label htmlFor="website">Leave this field empty</label><input id="website" name="_honey" tabIndex={-1} autoComplete="off"/></div>
    <div className="form-row"><div className="form-field"><label htmlFor="name">Your name</label><Input id="name" name="name" autoComplete="name" placeholder="Alex Morgan" required minLength={2} maxLength={100}/></div><div className="form-field"><label htmlFor="email">Email address</label><Input id="email" name="email" type="email" autoComplete="email" placeholder="alex@company.com" required maxLength={254}/></div></div>
    <div className="form-field"><label htmlFor="subject">What’s it about?</label><Input id="subject" name="subject" placeholder="A role, a project, or a question" required minLength={3} maxLength={160}/></div>
    <div className="form-field"><label htmlFor="message">Your message</label><Textarea id="message" name="message" placeholder="Tell me a little about what you have in mind…" required minLength={10} maxLength={5000} rows={5}/></div>
    <div className="form-footer"><Button type="submit" className="send-button" disabled={sending}>{sending?'Continuing…':'Send message'} <ArrowUpRight size={16}/></Button><span>No email app needed.</span></div>
    <p className="form-privacy">Your name, email, and message are sent through <a href="https://formsubmit.co/privacy.pdf" target="_blank" rel="noreferrer">FormSubmit</a> so I can reply. A spam check may open before sending.</p>
    {sending && <p className="submission-note" role="status">Opening the secure submission page. If it doesn’t open, <button type="button" onClick={()=>setSending(false)}>try again</button> or <a href="mailto:singhishdeep32@gmail.com">email me directly</a>.</p>}
  </form>;
}
