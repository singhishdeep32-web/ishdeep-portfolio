import assert from 'node:assert/strict';
import test from 'node:test';
const { default: worker } = await import('../dist/server/index.js');
async function render(path) {
  const response = await worker.fetch(new Request('https://portfolio.example' + path, {headers:{accept:'text/html'}}), {ASSETS:{fetch:async()=>new Response('Not found',{status:404})}}, {waitUntil(){},passThroughOnException(){}});
  assert.equal(response.status,200);
  return response.text();
}
test('portfolio exposes CV sections and a native contact form with fixed recipient and validation',async()=>{
  const html=await render('/');
  for(const id of ['about','experience','work','skills','education','contact']) assert.match(html,new RegExp('id="'+id+'"'));
  assert.match(html,/action="https:\/\/formsubmit\.co\/singhishdeep32@gmail\.com"/);
  assert.match(html,/method="POST"/i);
  for(const name of ['name','email','subject','message']) {
    assert.match(html,new RegExp('<(?:input|textarea)(?=[^>]*name="'+name+'")(?=[^>]*required)[^>]*>'));
  }
  assert.match(html, /name="_next"[^>]*value="https:\/\/ishdeep-singh-portfolio.singhishdeep32.chatgpt.site\/thanks"/);
  assert.match(html,/name="_honey"/);
  assert.doesNotMatch(html,/name="_captcha"[^>]*value="false"/);
  assert.match(html,/href="\/Ishdeep-Singh-Resume.pdf"[^>]*download/);
  assert.match(html,/application\/ld\+json/);
});
test('thank-you page renders without being indexed',async()=>{
  const html=await render('/thanks');
  assert.match(html,/Your contact form has been submitted/);
  assert.match(html,/noindex/);
  assert.match(html,/Back to my portfolio/);
});
