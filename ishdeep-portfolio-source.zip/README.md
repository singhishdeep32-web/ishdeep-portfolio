# Ishdeep Singh — Portfolio

A minimal, responsive CV website for Ishdeep Singh, a developer and AI trainer based in Patiala, India.

Live website: https://ishdeep-singh-portfolio.singhishdeep32.chatgpt.site

## Features

- Clear navigation to experience, projects, skills, background, and contact
- Downloadable original PDF resume
- Accessible native contact form, required-field validation, spam honeypot, and FormSubmit spam check
- Copy-email button and direct email, GitHub, and LinkedIn links
- Responsive and print styles, reduced-motion support, keyboard focus indicators
- Search metadata, structured profile data, robots.txt, and sitemap

## Contact form activation

The form sends to `singhishdeep32@gmail.com` through FormSubmit. It does not expose an email-service password or API key.

**Activation is pending verification.** Submit the form from the live website, then open the activation email from FormSubmit in the recipient mailbox and confirm the form. Check spam if needed. Send another test and confirm it reaches the inbox before considering delivery verified.

The native submission opens FormSubmit for its spam check and returns to `/thanks` after submission. Direct email remains available. Local production rendering is tested; actual inbox delivery has not been verified because the setup request was blocked by the execution environment.

Docs: https://formsubmit.co/documentation

## Development

Requires Node 22.13 or newer and npm.

```sh
npm run install:ci
npm run build
node --test tests/rendered-html.test.mjs
```

The project uses React, Vinext, TypeScript, and Cloudflare-compatible output. Preserve the existing build scripts and lockfile.

## Content

| File | Purpose |
| --- | --- |
| `app/page.tsx` | CV, skills, project and experience content |
| `app/contact-form.tsx` | Form fields and email destination |
| `app/copy-email.tsx` | Clipboard interaction |
| `app/thanks/page.tsx` | Return page after contact submission |
| `app/globals.css` | Responsive theme and print layout |
| `app/layout.tsx` | Search metadata and structured profile |
| `public/Ishdeep-Singh-Resume.pdf` | Original resume download |

For a new domain, update canonical metadata, sitemap, robots.txt, and the form's `_url` and `_next` values together. Changing the recipient requires FormSubmit activation again. The AI trading bot remains clearly marked as in development.

## GitHub publishing

A new GitHub repository is not yet created. The site source is ready to upload once an empty repository exists under `singhishdeep32-web` and is accessible to the GitHub connection. Do not commit API keys, `.env` files, local caches, or build output.
